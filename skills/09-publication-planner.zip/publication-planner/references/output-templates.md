# Output Templates

## Venue Comparison

| Venue | Audience and topical fit | Recent comparable work | Format and length | Review model and timing | Access, license, and fees | Data, code, ethics, and AI policies | Trust signals | Date checked | Open questions |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## Submission Plan

- Readiness gaps
- Researcher-selected target sequence
- Required manuscript components
- Reporting and disclosure requirements
- Contributor approvals
- Data, code, permissions, and accessibility tasks
- Dates and dependencies
- Decision points and backup options
- Final human authorization checkpoint
