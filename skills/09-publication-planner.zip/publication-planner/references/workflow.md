# Workflow

1. Identify the work's audience, contribution, genre, method, length, readiness, and practical constraints.
2. Generate a bounded venue set from citations, disciplinary knowledge, indexes, societies, repositories, conferences, and the researcher's priorities.
3. Verify each venue on its current official site: aims and scope, audience, accepted formats, length, review model, schedule or deadline, fees, access and license, copyright, archiving, preprints, data or code, reporting standards, ethics, conflicts, AI disclosure, and submission materials.
4. Check transparency and trust signals using independent authoritative sources when appropriate. Resolve journal title or publisher ambiguity before relying on a page.
5. Read several recent relevant items to assess actual fit rather than relying only on the stated scope.
6. Compare readership and scholarly fit alongside cost, time, access, preservation, review, and compliance. Do not rank solely by a metric or prestige.
7. Record direct links, date checked, contradictions, and unresolved questions.
8. Tailor title, abstract, keywords, and cover materials without changing the findings or overstating contribution.
9. Build a submission checklist and workback schedule, including coauthor or contributor approval and required disclosures.
10. Stop for human authorization before any external action or acceptance of terms.
