# Venue Due Diligence

Evaluate the whole pattern. Useful trust and transparency questions include:

- Is the title unambiguous, and are ownership, publisher, society affiliation, editorial leadership, and contact information clear?
- Are aims, audience, article types, peer-review process, decision responsibility, fees, waivers, access, copyright, license, archiving, and publishing schedule explained?
- Are authorship, contributorship, conflicts, ethics, misconduct, complaints, corrections, retractions, data, reproducibility, and intellectual-property policies visible?
- Are editorial-board members identifiable and plausibly connected to the field?
- Do recent published items match the stated scope and quality claims?
- Are claims about indexing, metrics, turnaround, and acceptance verifiable from the relevant service rather than only the venue's marketing?
- Does solicitation language create pressure, guarantee acceptance, imitate another venue, or conceal fees?

Authoritative starting points, checked August 27, 2026:

- Think. Check. Submit.: https://thinkchecksubmit.org/
- Principles of Transparency and Best Practice in Scholarly Publishing: https://doaj.org/apply/transparency/
- COPE publication-ethics resources: https://publicationethics.org/
- CRediT contributor roles: https://credit.niso.org/

Use current venue and disciplinary policies. CRediT describes contributions; it does not itself determine authorship. AI tools cannot accept authorship responsibility. Verify current publisher policy and disclose AI use when required.
