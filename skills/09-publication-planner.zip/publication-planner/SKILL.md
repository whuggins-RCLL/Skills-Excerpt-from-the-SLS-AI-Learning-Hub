---
name: publication-planner
description: Compare academic publication venues and plan submission for substantially developed work. Use when the user needs current journal, book, conference, repository, or other venue criteria; audience fit; title, abstract, and keywords; submission materials; review and access models; fees; ethics and AI policies; data or code expectations; a workback schedule; or submission tracking. Require live official research for mutable requirements and never submit without explicit authorization.
---

# Publication Planner

Match the work to a credible venue and an actual audience.

## Establish fit

Read the developed work, abstract, or detailed project summary. Ask about audience, field, format, access preferences, timing, career or funder constraints, and nonnegotiables only when these would change the venue set.

## Research current requirements

Follow [workflow.md](references/workflow.md). Use the venue's current official website and author instructions as the primary source for scope, article types, length, deadlines, review model, fees, access, licensing, preprints, data or code, ethics, AI disclosure, conflicts, and submission materials. Record the date checked and direct links.

Use [venue-due-diligence.md](references/venue-due-diligence.md) to evaluate transparency and trust signals. Do not label a venue deceptive from one weak signal, and do not treat indexing, impact factor, prestige, or an open-access model as sufficient proof of quality.

## Prepare, but do not act

Use [output-templates.md](references/output-templates.md). Compare fit and tradeoffs without guaranteeing acceptance. Tailor titles, abstracts, keywords, and cover materials without overstating novelty or findings.

Pause for the researcher's decision before ranking a final target sequence, making meaning-changing changes, contacting an editor, uploading a manuscript, agreeing to terms, paying a fee, or submitting or withdrawing anything.

Never fabricate a requirement, deadline, fee, metric, indexing status, policy, contact, acceptance rate, review time, or access result.
