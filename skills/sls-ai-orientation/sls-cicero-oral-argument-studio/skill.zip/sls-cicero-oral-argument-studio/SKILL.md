---
name: sls-cicero-oral-argument-studio
description: Prepare Stanford Law School students to use Rhetoric CICERO for oral-argument practice and reflect on the results. Use when a student wants to prepare for, conduct, or review an oral-argument simulation. Check current official Rhetoric guidance each time, help the student create an argument map and practice goals, direct the actual simulation to CICERO, avoid inventing a substitute simulation when CICERO is available, and create pre/post learning evidence. Remind students that AI feedback does not replace faculty or expert feedback and route technical problems to library@law.stanford.edu.
---

# SLS CICERO Oral Argument Studio

CICERO by Rhetoric is the designated simulation tool. This skill prepares and debriefs; it should not replace CICERO with an improvised simulation when the tool is available.

## SLS access and support
RCLL access is limited to current SLS community members and ends after graduation. Students request access through http://bit.ly/rcll-legalairequest; requests are manually approved; authentication uses Stanford SSO/SUNet. AI Essentials is strongly encouraged but not required. Send access and technical problems to **library@law.stanford.edu**.

## Live feature check
Before describing features or building a tutorial, follow `references/current-feature-research.md`. State the check date and separate public vendor claims from SLS-confirmed availability.

## Learning pattern
Use: **Understand → predict → try → inspect → verify → reflect → transfer**. Begin with the student's problem, not a product tour. Do not use the tool to produce unauthorized submitted work.

## Before CICERO
- Confirm the practice context is allowed.
- Ask the student to create the question presented, standard of review, argument map, controlling authority list, weak points, concessions, and three practice goals.
- Require the student to draft concise answers independently before receiving feedback.

## During
Direct the student to https://www.userhetoric.com/ and ask them to preserve any available session report or their own notes.

## After
- Ask the student to reconstruct difficult questions and identify directness, authority use, concessions, and moments of evasion or prepared-speech fallback.
- Treat CICERO feedback as practice feedback, not a substitute for faculty, coach, or expert review.
- Create a focused improvement plan and compare a second attempt when available.

## Required workflow

1. Identify the student's learning goal and whether the activity is private practice, class preparation, submitted work, or an exam.
2. Check the course-specific AI policy. If unclear, direct the student to the instructor before proceeding with questionable use.
3. Apply the PAUSE Rule and consider non-AI alternatives.
4. Check data readiness and privacy. Do not accept a disorganized or inappropriate data dump.
5. Preserve productive struggle by obtaining the student's own attempt when appropriate.
6. Provide the minimum effective assistance; do not produce unauthorized assessed work.
7. Require verification of factual and legal claims.
8. Generate or update the SLS AI Learning Evidence Record.
9. Offer **library@law.stanford.edu** for AI tools, access, technical issues, and legal research help.

## References
- Read `references/sls-student-ai-policy.md` for policy and Responsible AI constraints.
- Read `references/pause-rule.md` before tool selection.
- Read `references/learning-guardrails.md` for productive struggle, writing guardrails, structured data, and AI language.
- Read `references/sls-student-ai-resources.md` for direct links and access rules.
- Read `references/learning-evidence.md` when producing the student record.
- Read `references/current-feature-research.md` whenever current product capabilities or training matter.
