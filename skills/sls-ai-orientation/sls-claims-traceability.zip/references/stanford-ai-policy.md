# Stanford Law School AI-use guardrail

Verified against official Stanford sources on August 18, 2026.

## Controlling principles

- Course-specific instructions control. Instructors must communicate their generative-AI policy.
- If an SLS course has no course-specific AI policy, students may use generative AI to support learning and to develop or refine their own ideas, but may not use it to generate content presented as their own.
- Under the default SLS rule, using AI while taking an exam or to draft or revise any portion of submitted work -- including drafting/revising paper or clinic text, generating citations, or fixing citation format -- requires advance disclosure to the instructor and explicit written authorization before use.
- Academic norms on plagiarism and accuracy always apply. In coursework involving legal practice, applicable professional-responsibility duties also apply.
- When unsure whether a use is permitted, require the student to ask the instructor and disclose the proposed use before proceeding.

## How this skill must apply the rule

1. Before paper-specific review, determine whether the writing is intended for submission in an SLS course or clinic.
2. If yes, require either (a) the course AI policy, or (b) the student's confirmation that the instructor has authorized this exact kind of AI review in writing. Do not infer permission from silence.
3. If permission is absent or unclear, stop before line-level comments, Bluebook correction, or paper-specific revision advice. Offer only general writing instruction that does not analyze or revise the submitted paper.
4. Even when authorized, do not write or rewrite the student's paper. Flag issues, explain why they matter, ask revision questions, and offer revision strategies.
5. For clinic or practice-related materials, do not treat platform approval as a substitute for professional-responsibility, supervisor, confidentiality, or matter-specific requirements.

## Stanford data handling

Stanford currently provides ChatGPT Edu and lists it as approved for Stanford data at multiple risk levels when used through the Stanford-provided account. Connectors/plugins have separate review and permission rules. Apply the narrowest-access principle and avoid unnecessary sensitive data.

Official sources:
- SLS Student Affairs, Use of Generative AI Technology: https://law.stanford.edu/office-of-student-affairs/use-of-generative-ai-technology/
- Stanford UIT, OpenAI ChatGPT Edu: https://uit.stanford.edu/service/openai-chatgpt-edu
- Stanford UIT, Responsible AI at Stanford: https://uit.stanford.edu/security/responsibleai
- Stanford UIT, Approved Connectors for AI Services: https://uit.stanford.edu/ai/connectors
