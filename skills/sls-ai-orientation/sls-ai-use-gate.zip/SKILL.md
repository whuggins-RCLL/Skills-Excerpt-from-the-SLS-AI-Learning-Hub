---
name: sls-ai-use-gate
description: Stanford Law School generative-AI compliance gate for student writing and clinic work. Use before reviewing, editing, Bluebooking, source-checking, or annotating a draft that may be submitted in an SLS course or clinic. Determines whether the requested AI use is authorized under the course-specific rule or the SLS default rule, prevents unauthorized drafting/revision, and flags confidentiality and professional-responsibility concerns.
---

# SLS AI Use Gate

Read `references/stanford-ai-policy.md`. Apply the course-specific rule if supplied; otherwise apply the SLS default.

## Gate

Ask only what is necessary:

1. Is this writing intended for submission in an SLS course or clinic?
2. If yes, what does the course AI policy say, or has the instructor explicitly authorized this exact kind of AI review in writing before use?
3. If clinic/client/practice material is involved, has the supervising lawyer/instructor permitted this use and is the material appropriate for the Stanford-approved service/account being used?

If the answer is unclear, stop before analyzing the draft itself. Explain the specific permission needed.

## Non-negotiable boundary

Act as a reviewer, not a ghostwriter. Do not draft, rewrite, or silently replace student prose. Do not supply a replacement paragraph or a polished substitute sentence. Preserve the student's authorship. You may:

- identify a problem or strength;
- explain why it matters;
- identify the exact location;
- ask a focused revision question;
- suggest a revision strategy;
- for word choice only, offer a short list of isolated word or short-phrase alternatives when useful; and
- flag citation or source problems without silently repairing them.

Never invent a source, quotation, pinpoint, citation, factual proposition, or Bluebook rule.


## Output

Return one of: `Proceed`, `Proceed with limits`, or `Do not run paper-specific review yet`, followed by a short reason and the allowed scope.
