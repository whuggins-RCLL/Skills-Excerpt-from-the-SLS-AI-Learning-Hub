# Bluebook audit scope

Current edition assumption: The Bluebook, 22nd ed. (2025), unless the assignment specifies otherwise.

The official Bluebook site distinguishes Bluepages for court documents and legal memoranda from Whitepages for law-review footnotes. The public Quick Style Guide provides common examples, but much of the full rule text is subscription content. Do not reconstruct or reproduce proprietary rule text.

Audit strategy:

1. Identify document type and therefore Bluepages vs. Whitepages orientation.
2. Identify source type.
3. Parse each citation into components.
4. Compare component order, abbreviations, typography, pincite, court/year, parenthetical, subsequent history, and short form against rules you can verify.
5. Use the public Quick Style Guide for common patterns.
6. If the precise rule cannot be verified from an accessible authoritative source, name the rule/table category and tell the student to verify in their Bluebook 22nd edition.
7. Never claim a citation is compliant solely because it resembles a common pattern.

Official sources:
- Bluebook Online home / edition information: https://www.legalbluebook.com/
- Bluebook Online Quick Style Guide / Whitepages examples: https://www.legalbluebook.com/bluebook

SLS-specific warning: the SLS default AI policy explicitly identifies generating citations and fixing citation format as uses that require advance disclosure and written instructor authorization when the work will be submitted. The audit must therefore pass the policy gate before paper-specific Bluebook review.
