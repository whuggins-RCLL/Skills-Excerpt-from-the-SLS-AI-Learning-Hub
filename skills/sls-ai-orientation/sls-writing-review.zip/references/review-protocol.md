# Full review protocol and structured output

## Review sequence

After the SLS AI-use gate permits paper-specific review, run the checks in this order:

1. Argument and thesis
2. Organization and flow
3. Clarity, concision, word choice, and precision
4. Audience reception and tone
5. Counterargument and vulnerabilities
6. Claims and source traceability
7. Bluebook issue spotting
8. Genre fit

Run the source-traceability pass independently from the prose-quality passes so persuasive writing does not substitute for evidence.

## Issue JSON schema

Create a UTF-8 JSON file with this structure before running the DOCX annotation script:

```json
{
  "title": "SLS Writing Review",
  "summary": [
    "Short finding 1",
    "Short finding 2"
  ],
  "issues": [
    {
      "category": "Argument | Flow | Clarity | Audience | Counterargument | Traceability | Bluebook | Genre",
      "severity": "Critical | High | Medium | Low",
      "paragraph_index": 12,
      "anchor_text": "an exact short excerpt from the student's paragraph",
      "observation": "what the reviewer notices, without rewriting",
      "why_it_matters": "reader/legal/source consequence",
      "revision_question": "a question the student should answer while revising",
      "student_action": "a strategy, research step, or verification task; not replacement prose"
    }
  ],
  "traceability": [
    {
      "claim_location": "p. 4, para. 12 or a short anchor",
      "claim": "the student's claim",
      "cited_source": "citation or source marker",
      "source_found": "yes | no | inaccessible",
      "support_status": "Supported | Partially supported | Unsupported | Source not found | Source inaccessible | Needs pinpoint verification | Needs citator/currentness check | Not externally verifiable",
      "support_location": "page/section/paragraph when available",
      "verification_source": "title or authority",
      "verification_url": "https://...",
      "concern": "what is missing or inconsistent",
      "student_action": "what to verify or research next"
    }
  ]
}
```

`paragraph_index` is 1-based across body paragraphs. Use an exact `anchor_text` whenever possible. The annotation script can fall back to the paragraph index.

## Review copy rule

The Word review copy must preserve every original word. Add Word comments anchored to relevant paragraphs and append an `AI Writing Review Appendix` as tracked insertions. The appendix may summarize findings and traceability, but it must not contain replacement prose. This approach provides native tracked changes without rewriting the student's paper.
