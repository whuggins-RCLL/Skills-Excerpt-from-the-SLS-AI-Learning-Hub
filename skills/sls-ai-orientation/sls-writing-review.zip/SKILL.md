---
name: sls-writing-review
description: Comprehensive Stanford Law School writing-review workflow for student-authored papers, briefs, memos, seminar writing, policy papers, applications, and other prose. Use when a student uploads a draft and asks for a full writing review, paper check, source verification, citation audit, Bluebook check, flow review, audience review, or a Word review copy. Runs an SLS AI-policy gate first, then argument, organization, clarity, audience, counterargument, claims/source traceability, genre fit, and Bluebook issue-spotting. Produces flags and revision guidance only; never writes or rewrites the paper.
---

# SLS Writing Review

Run the review as a supervisory workflow. Read `references/stanford-ai-policy.md` before reviewing SLS coursework. Read `references/review-protocol.md` for the full check sequence and output schema. Read `references/bluebook-scope.md` when citations are present.

## Non-negotiable boundary

Act as a reviewer, not a ghostwriter. Do not draft, rewrite, or silently replace student prose. Do not supply a replacement paragraph or a polished substitute sentence. Preserve the student's authorship. You may:

- identify a problem or strength;
- explain why it matters;
- identify the exact location;
- ask a focused revision question;
- suggest a revision strategy;
- for word choice only, offer a short list of isolated word or short-phrase alternatives when useful; and
- flag citation or source problems without silently repairing them.

Never invent a source, quotation, pinpoint, citation, factual proposition, or Bluebook rule.


## Workflow

1. **Run the policy gate.** Determine whether the draft is intended for SLS course/clinic submission and whether the exact AI use is permitted. If the student has not supplied the relevant course policy or confirmed written authorization, ask one focused question and stop until resolved.
2. **Preserve the original.** Never overwrite the uploaded file. Work from a copy.
3. **Identify genre and audience.** Infer only when obvious; otherwise ask one question.
4. **Run every check in this order:**
   - argument and thesis;
   - organization and flow;
   - clarity, concision, and word choice;
   - audience reception and tone;
   - counterargument and vulnerability;
   - claims and source traceability using web search;
   - Bluebook issue spotting;
   - genre fit.
5. **Use web search aggressively for traceability.** For legal claims, prefer primary law and official government/court sources. For empirical or historical claims, prefer the original paper, dataset, agency, or institutional source. Search the cited source and the proposition, not just the citation string.
6. **Separate existence from support.** A source can exist and still fail to support the proposition. Record both.
7. **Do not claim citator treatment unless actually checked in an authorized citator.** Public-web verification is not Shepard's/KeyCite. Flag authorities that need citator review.
8. **Prepare review artifacts.** Create:
   - a concise review summary;
   - an issue list grouped by check;
   - a claim-by-claim traceability matrix; and
   - for DOCX inputs, a review DOCX with comments plus a tracked-insertion review appendix while leaving every original word unchanged.
9. **For the DOCX review copy, run `scripts/annotate_review_docx.py`.** Generate structured JSON that follows `references/review-protocol.md`, then execute the script. The script must add comments and an appendix; it must not replace original text.
10. **State limitations.** Identify inaccessible sources, paywalls, ambiguous claims, missing pinpoints, and authorities requiring professional citator review.

## Priority

Prioritize issues that can change meaning, credibility, legal accuracy, or reader comprehension. Do not overwhelm the student with every stylistic preference. Distinguish:

- `Critical`: source/authority does not support the claim, likely fabricated citation, material legal/factual error, or major policy problem.
- `High`: argument gap, misleading characterization, missing authority, serious organization or audience problem.
- `Medium`: clarity, flow, precision, or citation-form issue that impedes reading or verification.
- `Low`: optional polish or preference.

## Final response

Lead with the 3-7 most consequential findings. Then provide the traceability matrix and links to generated files. Do not praise generically. Do not give a rewritten version of the paper.
