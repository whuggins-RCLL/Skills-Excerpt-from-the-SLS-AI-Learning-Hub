#!/usr/bin/env python3
"""Add review comments and a tracked-insertion appendix to a DOCX without rewriting original text.

Usage:
  python annotate_review_docx.py input.docx review.json output.docx

The JSON schema is documented in references/review-protocol.md.
"""
from __future__ import annotations
import csv
import json
import shutil
import sys
import tempfile
import zipfile
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from lxml import etree

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PR = "http://schemas.openxmlformats.org/package/2006/relationships"
CT = "http://schemas.openxmlformats.org/package/2006/content-types"
NS = {"w": W, "r": R}
qn = lambda ns, tag: f"{{{ns}}}{tag}"

COMMENT_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
COMMENTS_CT = "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml"


def read_xml(path: Path):
    return etree.parse(str(path))


def write_xml(tree, path: Path):
    tree.write(str(path), encoding="UTF-8", xml_declaration=True, standalone="yes")


def paragraph_text(p):
    return "".join(p.xpath('.//w:t/text() | .//w:delText/text()', namespaces=NS))


def body_paragraphs(doc_tree):
    body = doc_tree.getroot().find(qn(W, "body"))
    return [c for c in body if c.tag == qn(W, "p")]


def max_numeric_id(tree, xpath, attr_name):
    vals = []
    for el in tree.xpath(xpath, namespaces=NS):
        v = el.get(qn(W, attr_name))
        if v is not None:
            try:
                vals.append(int(v))
            except ValueError:
                pass
    return max(vals) if vals else -1


def ensure_settings(work: Path):
    p = work / "word" / "settings.xml"
    tree = read_xml(p)
    root = tree.getroot()
    if root.find(qn(W, "trackRevisions")) is None:
        root.insert(0, etree.Element(qn(W, "trackRevisions")))
    write_xml(tree, p)


def ensure_comments_part(work: Path):
    comments_path = work / "word" / "comments.xml"
    if comments_path.exists():
        comments_tree = read_xml(comments_path)
    else:
        root = etree.Element(qn(W, "comments"), nsmap={"w": W})
        comments_tree = etree.ElementTree(root)

    rels_path = work / "word" / "_rels" / "document.xml.rels"
    rels_tree = read_xml(rels_path)
    rels_root = rels_tree.getroot()
    has_rel = any(r.get("Type") == COMMENT_REL for r in rels_root)
    if not has_rel:
        ids = []
        for r in rels_root:
            rid = r.get("Id", "")
            if rid.startswith("rId"):
                try: ids.append(int(rid[3:]))
                except ValueError: pass
        rid = f"rId{max(ids, default=0)+1}"
        rel = etree.SubElement(rels_root, qn(PR, "Relationship"))
        rel.set("Id", rid)
        rel.set("Type", COMMENT_REL)
        rel.set("Target", "comments.xml")
        write_xml(rels_tree, rels_path)

    ct_path = work / "[Content_Types].xml"
    ct_tree = read_xml(ct_path)
    ct_root = ct_tree.getroot()
    if not any(o.get("PartName") == "/word/comments.xml" for o in ct_root):
        o = etree.SubElement(ct_root, qn(CT, "Override"))
        o.set("PartName", "/word/comments.xml")
        o.set("ContentType", COMMENTS_CT)
        write_xml(ct_tree, ct_path)
    return comments_tree, comments_path


def add_comment_to_paragraph(p, comment_id: int, text: str):
    children = list(p)
    start_idx = 1 if children and children[0].tag == qn(W, "pPr") else 0
    end_idx = len(children)
    start = etree.Element(qn(W, "commentRangeStart"))
    start.set(qn(W, "id"), str(comment_id))
    p.insert(start_idx, start)

    # recompute after insertion and insert range end before any paragraph-level proofing tail is unnecessary;
    # put at end so the comment applies to the full paragraph content.
    end = etree.Element(qn(W, "commentRangeEnd"))
    end.set(qn(W, "id"), str(comment_id))
    p.append(end)
    rr = etree.SubElement(p, qn(W, "r"))
    rpr = etree.SubElement(rr, qn(W, "rPr"))
    rstyle = etree.SubElement(rpr, qn(W, "rStyle"))
    rstyle.set(qn(W, "val"), "CommentReference")
    ref = etree.SubElement(rr, qn(W, "commentReference"))
    ref.set(qn(W, "id"), str(comment_id))


def add_comment_record(comments_root, comment_id: int, text: str, author="SLS Writing Review"):
    c = etree.SubElement(comments_root, qn(W, "comment"))
    c.set(qn(W, "id"), str(comment_id))
    c.set(qn(W, "author"), author)
    c.set(qn(W, "date"), datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"))
    p = etree.SubElement(c, qn(W, "p"))
    r = etree.SubElement(p, qn(W, "r"))
    t = etree.SubElement(r, qn(W, "t"))
    t.text = text


def tracked_paragraph(text: str, change_id: int, bold=False, style=None):
    p = etree.Element(qn(W, "p"))
    if style:
        ppr = etree.SubElement(p, qn(W, "pPr"))
        ps = etree.SubElement(ppr, qn(W, "pStyle"))
        ps.set(qn(W, "val"), style)
    ins = etree.SubElement(p, qn(W, "ins"))
    ins.set(qn(W, "id"), str(change_id))
    ins.set(qn(W, "author"), "SLS Writing Review")
    ins.set(qn(W, "date"), datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"))
    r = etree.SubElement(ins, qn(W, "r"))
    if bold:
        rpr = etree.SubElement(r, qn(W, "rPr"))
        etree.SubElement(rpr, qn(W, "b"))
    t = etree.SubElement(r, qn(W, "t"))
    if text.startswith(" ") or text.endswith(" "):
        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    t.text = text
    return p


def issue_comment(issue):
    bits = [f"[{issue.get('category','Review')} / {issue.get('severity','')}]"]
    if issue.get("observation"): bits.append(issue["observation"])
    if issue.get("why_it_matters"): bits.append("Why it matters: " + issue["why_it_matters"])
    if issue.get("revision_question"): bits.append("Revision question: " + issue["revision_question"])
    if issue.get("student_action"): bits.append("Student action: " + issue["student_action"])
    return "\n".join(bits)


def choose_paragraph(paras, issue):
    anchor = (issue.get("anchor_text") or "").strip()
    if anchor:
        matches = [p for p in paras if anchor in paragraph_text(p)]
        if len(matches) == 1:
            return matches[0]
    idx = issue.get("paragraph_index")
    if isinstance(idx, int) and 1 <= idx <= len(paras):
        return paras[idx-1]
    return None


def appendix_lines(review):
    lines = []
    lines.append(("AI Writing Review Appendix", True))
    lines.append(("This appendix was added as tracked insertions. The student's original prose was not rewritten.", False))
    for s in review.get("summary", []):
        lines.append((f"Summary: {s}", False))
    if review.get("issues"):
        lines.append(("Review issues", True))
        for i, issue in enumerate(review["issues"], 1):
            loc = issue.get("paragraph_index") or issue.get("anchor_text") or "location not resolved"
            text = f"{i}. [{issue.get('severity','')}] {issue.get('category','')}; location: {loc}. {issue.get('observation','')}"
            if issue.get("student_action"):
                text += " Student action: " + issue["student_action"]
            lines.append((text, False))
    if review.get("traceability"):
        lines.append(("Claims and source traceability", True))
        for i, row in enumerate(review["traceability"], 1):
            text = f"{i}. {row.get('claim_location','')}: {row.get('support_status','')}. Claim: {row.get('claim','')}"
            if row.get("verification_source"):
                text += f" Verification: {row.get('verification_source')}"
            if row.get("verification_url"):
                text += f" ({row.get('verification_url')})"
            if row.get("concern"):
                text += f" Concern: {row.get('concern')}"
            if row.get("student_action"):
                text += f" Student action: {row.get('student_action')}"
            lines.append((text, False))
    return lines


def write_trace_csv(review, path: Path):
    rows = review.get("traceability", [])
    fields = ["claim_location","claim","cited_source","source_found","support_status","support_location","verification_source","verification_url","concern","student_action"]
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for row in rows:
            w.writerow(row)


def validate_review(review):
    if not isinstance(review, dict):
        raise ValueError("review JSON must be an object")
    for key in ("issues", "traceability"):
        if key in review and not isinstance(review[key], list):
            raise ValueError(f"{key} must be a list")
    forbidden = ("replacement_text", "rewritten_sentence", "rewrite")
    for issue in review.get("issues", []):
        for k in forbidden:
            if k in issue and issue[k]:
                raise ValueError(f"Forbidden field {k}: this workflow must not rewrite student prose")


def main():
    if len(sys.argv) not in (4,5):
        print("Usage: annotate_review_docx.py INPUT.docx REVIEW.json OUTPUT.docx [TRACEABILITY.csv]", file=sys.stderr)
        return 2
    src, review_path, out = map(Path, sys.argv[1:4])
    csv_out = Path(sys.argv[4]) if len(sys.argv) == 5 else out.with_name(out.stem + "_traceability.csv")
    if src.suffix.lower() != ".docx" or out.suffix.lower() != ".docx":
        raise ValueError("Input and output must be .docx files")
    review = json.loads(review_path.read_text(encoding="utf-8"))
    validate_review(review)

    with tempfile.TemporaryDirectory(prefix="sls_review_") as td:
        work = Path(td)
        with zipfile.ZipFile(src, "r") as z:
            z.extractall(work)

        doc_path = work / "word" / "document.xml"
        doc_tree = read_xml(doc_path)
        paras = body_paragraphs(doc_tree)
        original_texts = [paragraph_text(p) for p in paras]

        comments_tree, comments_path = ensure_comments_part(work)
        comments_root = comments_tree.getroot()
        existing_comment_ids = []
        for c in comments_root.findall(qn(W, "comment")):
            try: existing_comment_ids.append(int(c.get(qn(W, "id"))))
            except Exception: pass
        cid = max(existing_comment_ids, default=-1) + 1

        unresolved = []
        for issue in review.get("issues", []):
            p = choose_paragraph(paras, issue)
            if p is None:
                unresolved.append(issue)
                continue
            add_comment_to_paragraph(p, cid, issue_comment(issue))
            add_comment_record(comments_root, cid, issue_comment(issue))
            cid += 1

        # Append unresolved issues to summary; no original text is changed.
        if unresolved:
            review = deepcopy(review)
            review.setdefault("summary", []).append(f"{len(unresolved)} review issue(s) could not be anchored to a body paragraph and appear only in the appendix.")

        # tracked appendix before sectPr
        body = doc_tree.getroot().find(qn(W, "body"))
        sect = body.find(qn(W, "sectPr"))
        insert_at = list(body).index(sect) if sect is not None else len(body)
        change_id = max_numeric_id(doc_tree, './/w:ins | .//w:del', 'id') + 1
        for text, bold in appendix_lines(review):
            p = tracked_paragraph(text, change_id, bold=bold)
            body.insert(insert_at, p)
            insert_at += 1
            change_id += 1

        # Verify all original paragraph visible text is unchanged.
        current_paras = body_paragraphs(doc_tree)[:len(paras)]
        current_texts = [paragraph_text(p) for p in current_paras]
        if current_texts != original_texts:
            raise RuntimeError("Safety check failed: original paragraph text changed")

        write_xml(doc_tree, doc_path)
        write_xml(comments_tree, comments_path)
        ensure_settings(work)

        out.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
            for p in sorted(work.rglob("*")):
                if p.is_file():
                    z.write(p, p.relative_to(work).as_posix())

    write_trace_csv(review, csv_out)
    print(str(out))
    print(str(csv_out))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
