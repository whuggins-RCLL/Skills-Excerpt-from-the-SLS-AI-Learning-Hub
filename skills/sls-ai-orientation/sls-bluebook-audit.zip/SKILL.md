---
name: sls-bluebook-audit
description: Bluebook 22nd-edition citation issue-spotting for Stanford Law School student writing. Use when a student asks for Bluebook review, citation-format checking, short-form consistency, case/statute/journal/internet citation diagnostics, pincite checks, signal/order problems, or citation typography issues. Because SLS treats AI citation generation/fixing as revision of submitted work, run the policy gate first. Flag likely defects and rule categories without silently fixing or generating replacement citations.
---

# SLS Bluebook Audit

Read `references/stanford-ai-policy.md` and `references/bluebook-scope.md`.

## Non-negotiable boundary

Act as a reviewer, not a ghostwriter. Do not draft, rewrite, or silently replace student prose. Do not supply a replacement paragraph or a polished substitute sentence. Preserve the student's authorship. You may:

- identify a problem or strength;
- explain why it matters;
- identify the exact location;
- ask a focused revision question;
- suggest a revision strategy;
- for word choice only, offer a short list of isolated word or short-phrase alternatives when useful; and
- flag citation or source problems without silently repairing them.

Never invent a source, quotation, pinpoint, citation, factual proposition, or Bluebook rule.


## Scope

Use the 22nd edition as the current default unless the assignment specifies another edition or house style. Determine whether the document uses Bluepages (practice documents/memos) or Whitepages (academic/law-review footnotes) before judging form.

Check, where applicable:

- case names, reporter/court/year, and pincites;
- statutes and codes;
- regulations and administrative materials;
- books, articles, newspapers, and internet sources;
- short forms, `id.`, and cross-reference consistency;
- signals, order, parentheticals, explanatory phrases, and subsequent history;
- abbreviations, capitalization, italics/small-caps/roman type, spacing, and punctuation;
- quotation and alteration markers; and
- whether cited authorities can be resolved.

## Output

For each likely issue, provide location, current citation excerpt, issue category, relevant Bluebook rule/table number when confidently known, confidence (`high/medium/low`), and what the student should verify. Do not output a fully corrected citation.

If exact Bluebook text is unavailable behind the subscription, do not guess. Label the point `Verify in Bluebook 22nd ed.` The public Bluebook Quick Style Guide may support common examples but is not a substitute for the full rule set.
