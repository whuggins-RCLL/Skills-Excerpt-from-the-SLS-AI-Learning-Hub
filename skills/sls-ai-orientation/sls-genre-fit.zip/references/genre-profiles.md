# Genre profiles

Use these as functional checks, not rigid templates.

## Legal memorandum
- Predictive, candid, and reader-centered.
- Makes governing law and uncertainty explicit.
- Applies law to material facts and treats adverse authority seriously.
- Separates issue/rule explanation from application when useful.

## Brief / persuasive legal argument
- Seeks a concrete legal outcome.
- Frames the rule and facts strategically without mischaracterization.
- Addresses standard of review, remedy, adverse authority, and strongest counterarguments when relevant.

## Seminar / academic paper
- Makes an original, bounded claim.
- Situates the claim in existing literature or doctrine.
- Distinguishes description from normative argument.
- Shows why the contribution matters and addresses plausible objections.

## Policy paper
- Defines the problem, stakeholders, evidence, options, tradeoffs, implementation, and uncertainty.
- Connects recommendations to evidence and constraints.

## Client communication
- Prioritizes the client's decision and comprehension.
- States action items, deadlines, uncertainty, and risks plainly.
- Avoids unnecessary legal jargon.

## Cover letter / professional statement
- Uses specific evidence rather than generic self-description.
- Connects experience to the reader's needs.
- Maintains authentic voice and appropriate professional tone.

## General analytical essay
- States a controlling idea, develops it through logically ordered evidence, handles objections, and reaches a conclusion proportionate to the analysis.
