# Learning Evidence and AI-Use Log

Generate a concise Markdown record controlled by the student. Do not claim that a transcript proves academic integrity. Capture evidence of learning and judgment.

```markdown
# SLS AI Learning Evidence Record

## Context
Date:
Course or private-learning context:
Submitted work, exam, class preparation, or private practice:
Course policy checked:
Authorization required and obtained:

## Problem and PAUSE Decision
Learning goal:
Task definition:
AI-fit decision:
Non-AI alternatives considered:
New York Times Rule result:
Skills and verification capacity:
Expected workflow benefit:

## Independent Starting Point
[Student's attempt, prediction, analysis, or plan before AI assistance]

## Tool and Data
Tool used and why:
Materials supplied:
How sources were structured and labeled:
Sensitive information removed or avoided:

## Material AI Interactions
Prompt or action:
Purpose:
Relevant output or result:

## Verification
Claims, citations, quotations, or authorities checked:
Authoritative sources used:
Errors, omissions, or limitations found:
Unresolved questions:

## Student Judgment
Suggestions accepted and why:
Suggestions rejected and why:
Final decisions made by the student:

## Learning and Transfer
What I understand better:
What I can now do independently:
Where AI was not useful or appropriate:
What I will do differently next time:

## Disclosure
Accurate description of how AI influenced the work:
```

Log material prompts and decisions, not every trivial exchange.
