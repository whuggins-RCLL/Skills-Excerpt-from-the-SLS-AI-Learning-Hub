# PAUSE Rule

Use PAUSE before recommending or using AI.

## P — Pinpoint your Task
Break the goal into specific tasks. State the audience, constraints, expected evidence, and desired output. Apply **Task First, Tool Second**.

## A — Assess AI-fit
Ask whether AI is the right tool. Compare it with authoritative research sources, ordinary search, document tools, templates, spreadsheets, calculators, manual work, and human expertise. A recommendation not to use AI is a successful outcome.

## U — Use Ethically
Check course permission, privacy, confidentiality, intellectual property, licensing, data classification, disclosure, and professional obligations. Apply the **New York Times Rule**: would the student be comfortable if the use appeared on the front page and were accurately explained to the instructor? A yes does not override a policy prohibition.

## S — Self-Assess your Skills
Ask whether the student has enough knowledge and judgment to evaluate the output. If the student cannot verify accuracy and quality, stop or route to a qualified source. Apply the **Empty Room Test**: if AI disappeared, would the student retain the core skill needed to complete the task?

## E — Enhance Workflow
Count verification and editing time. Use AI only when it improves the total workflow while protecting quality and helping the student grow. Prefer tutor, sparring-partner, and feedback roles over task replacement.

Official PAUSE resource: https://sites.google.com/law.stanford.edu/ailearninghub/the-pause-rule
