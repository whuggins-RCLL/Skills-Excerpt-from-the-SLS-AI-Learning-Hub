# Output Templates

## Argument Map

- Central claim and claim type
- Scope and boundary conditions
- Supporting reasons
- Evidence for each reason
- Warrants
- Assumptions and uncertainty
- Alternative explanations
- Strongest counterarguments
- Possible responses
- Contrary or null evidence
- Revised defensible claim
- Implications and limits
- Evidence still needed
- Human judgment point

## Claim-Evidence Traceability Table

| Claim | Claim type | Evidence or source | What it supports | Warrant | Counterevidence or limit | Verification status | Revision needed |
| --- | --- | --- | --- | --- | --- | --- | --- |
