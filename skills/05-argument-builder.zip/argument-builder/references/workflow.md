# Workflow

1. State the proposed conclusion precisely and identify each claim type.
2. Define the claim's population, setting, period, conditions, and level of generality.
3. Inventory the evidence actually available and distinguish data, observations, texts, sources, established findings, and the researcher's interpretation.
4. State the warrant connecting each reason or item of evidence to the claim.
5. Test evidence fit:
   - Descriptive claims require representative or clearly bounded observation.
   - Correlational claims must not become causal without a defensible design and mechanism.
   - Causal claims require attention to alternatives, selection, confounding, timing, measurement, and external validity.
   - Interpretive claims require textual, historical, cultural, or material grounding and engagement with plausible counterreadings.
   - Theoretical claims require conceptual clarity, internal coherence, relationship to prior theory, and discriminating implications.
   - Normative claims must expose values, affected interests, tradeoffs, and the move from facts to recommendations.
   - Evaluative and design claims must identify criteria, comparison, implementation context, and unintended consequences.
6. Identify assumptions, uncertainty, boundary conditions, missing perspectives, and contrary or null evidence.
7. Build the strongest good-faith counterargument and determine what evidence would change the conclusion.
8. Revise the claim to the strongest supportable form.
9. Map implications without extending beyond the evidence.
10. Produce a traceable argument map and prioritized research needs.
