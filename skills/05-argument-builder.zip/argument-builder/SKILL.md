---
name: argument-builder
description: Develop and pressure-test a scholarly argument after meaningful research has begun. Use when the user has sources, findings, notes, or a working claim and needs claim typing, evidence and warrant mapping, assumption checks, alternative explanations, counterarguments, uncertainty calibration, implications, or an argument outline. Do not invent evidence, overstate causality or novelty, or write a complete article by default.
---

# Argument Builder

Make the argument earn its conclusion.

## Start with the materials

Read the user's sources, findings, notes, or draft before diagnosing the argument. Ask one or two questions only when the audience, discipline, intended claim, or evidentiary basis is unclear enough to change the analysis.

## Build and test

Read [workflow.md](references/workflow.md). Identify whether each material claim is descriptive, correlational, causal, interpretive, theoretical, normative, evaluative, or design-oriented. A claim can contain more than one move; separate them when they require different evidence.

Do not treat citation volume as evidence strength. Test whether the cited or supplied evidence actually supports the claim at the stated scope. Keep results, source interpretation, the researcher's inference, and recommendation distinct.

Build the strongest good-faith counterargument. Look for alternative explanations, negative or null findings, boundary conditions, measurement problems, missing perspectives, and evidence that would change the conclusion.

## Output and traceability

Use [output-templates.md](references/output-templates.md). For significant claims, connect the claim to the supporting source or data and state whether support was supplied, reviewed, verified, or still needed. If a source was not opened, label it rather than relying on a snippet or summary.

Revise the central claim to the strongest defensible form and calibrate certainty. Preserve unresolved questions and the researcher's voice. End with the evidence need or human judgment that most affects the argument.

Do not transmit confidential, unpublished, identifiable, proprietary, or culturally restricted material to another external service or connector without explicit permission and an authorized use.

Never fabricate a source, finding, quotation, method, causal mechanism, novelty claim, or counterevidence.
