# Workflow

1. Translate the question into information needs, source types, disciplinary contexts, and scope limits.
2. Locate orientation sources when needed: handbooks, reference works, review articles, bibliographies, or field guides. Use them to learn terminology and identify primary work, not as automatic final authority.
3. Build search concepts with synonyms, variant spellings, controlled vocabulary, names, places, dates, methods, identifiers, and cited works.
4. Search at least one field-appropriate index or collection when available. Add multidisciplinary, regional, archival, data, government, or grey-literature sources when they cover a genuine gap.
5. Use backward references, forward citation links, related-record tools, author searches, and organization searches.
6. Record database or platform, date, exact query, filters, result count when available, useful sources, and follow-up paths.
7. Open promising sources. Verify title, creators, date, venue or repository, version, DOI or stable identifier, and relevant content.
8. Evaluate fit, creation process, provenance, method, evidence, currency, independence, conflicts, and coverage. Do not reduce quality to journal prestige or peer-review status alone.
9. Seek contrary findings, alternative interpretations, null results, relevant non-English or regional work when feasible, and voices or source types the initial search may exclude.
10. Check corrections, retractions, and versions when material. Record exactly what system was checked and its limits.
11. Stop according to the requested depth, a documented saturation or coverage rule, or a human decision. Do not label a search exhaustive unless the method supports that claim.
12. Produce a source brief and traceability ledger with gaps and next searches.
