# Output Templates

## Search Plan and Log

| Information need | Source environment | Query or path | Date and filters | Result | Follow-up |
| --- | --- | --- | --- | --- | --- |

## Source Brief

For each important source, record:

- APA 7 citation and stable link or identifier;
- source type and why it fits the question;
- relevant claim, finding, data, or material;
- method or provenance;
- limitations, conflicts, and context;
- discovered, retrieved, reviewed, verified, or unable-to-verify status;
- correction, retraction, or version check when material.

## Evidence Ledger

| Research proposition | Supporting source | Exact support | Direct or inferential | Limits or contrary evidence | Verification status |
| --- | --- | --- | --- | --- | --- |
