# Discipline-Neutral Source Strategy

Match the source to the question rather than applying one universal hierarchy.

| Information need | Useful starting points | Essential checks |
| --- | --- | --- |
| Concept, field, or scholarly conversation | Recent reviews, handbooks, reference works, major bibliographies | Coverage, disciplinary framing, date, cited primary work |
| Empirical relationship or effect | Primary studies, datasets, methods papers, evidence syntheses | Design, sample, measures, analysis, uncertainty, replication, context |
| Historical or interpretive question | Primary texts, archives, critical editions, material objects, oral histories, scholarship | Provenance, edition, context, silences, translation, interpretive dispute |
| Policy, program, or institutional practice | Official documents and data plus independent evaluation and affected-community sources | Version, jurisdiction or scope, implementation, incentives, missing perspectives |
| Theory or concept development | Foundational works, later refinements, critiques, applications | Original meaning, schools of thought, translation, historical development |
| Technical claim | Standards, specifications, documentation, source code, benchmarks, independent studies | Version, test conditions, reproducibility, vendor interest, obsolescence |
| Dataset or statistical claim | Original dataset, codebook, methodology, version record, analysis | Provenance, definitions, missingness, weighting, license, update date |
| Current event or changing fact | Official records, direct statements, reputable reporting, archived versions | Event date versus publication date, corroboration, later correction |

Choose source environments by coverage. Examples may include the institution's library discovery service and catalog; disciplinary indexes such as PubMed, PsycINFO, ERIC, EconLit, MLA International Bibliography, Historical Abstracts, or subject repositories; multidisciplinary indexes such as Scopus or Web of Science; archives and special collections; WorldCat; dissertation databases; government and intergovernmental repositories; data and code repositories; Crossref, DataCite, or OpenAlex metadata; and publisher platforms. Availability varies. Never claim access without confirming it.

Apply the ACRL principle that authority is constructed and contextual, and treat searching as iterative strategic exploration. Adopted framework: https://www.ala.org/acrl/standards/ilframework

For scholarly-record checks, use the publisher or repository record first and supplement it with DOI metadata and update services when available:

- Crossref metadata retrieval: https://www.crossref.org/documentation/retrieve-metadata/
- Crossmark updates, corrections, and retractions: https://www.crossref.org/documentation/crossmark/

No single database, status service, or citation index proves completeness.
