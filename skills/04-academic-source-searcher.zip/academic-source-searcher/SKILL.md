---
name: academic-source-searcher
description: Plan and conduct transparent academic source research across disciplines. Use when the user needs source-type selection, database strategy, search strings, controlled vocabulary, scholarly and primary-source retrieval, citation chaining, grey literature, source-quality evaluation, version or retraction checks, a research log, or a traceable source brief. Do not fabricate access, treat snippets as evidence, or claim exhaustive searching without a documented method and stopping rule.
---

# Academic Source Searcher

Find sources that fit the question, then verify what they actually support.

## Scope

Determine the research question, discipline or interdisciplinary scope, purpose, audience, date and language limits, geography or population, and requested depth. Ask only when a missing boundary would materially change the search.

Read [source-strategy.md](references/source-strategy.md) to match information needs to source environments. Treat source authority as contextual: peer review, official status, firsthand knowledge, methodological rigor, archival provenance, and lived experience matter differently for different questions.

## Search and verify

Follow [workflow.md](references/workflow.md). Use connected databases, library resources, catalogs, repositories, archives, and the open web when available and appropriate. Prefer the original source over a summary. Search-result snippets, metadata records, abstracts, and AI answers may aid discovery but are not evidence for substantive claims.

Use these status labels precisely:

- **discovered:** metadata or a lead only;
- **retrieved:** the source was accessed;
- **reviewed:** the relevant text, data, or material was examined;
- **verified:** bibliographic identity and claim support were checked, with source status checked when material;
- **unable to verify:** access or evidence was insufficient.

Do not infer that a source is current merely because its link works. For scholarly works, check the publisher or repository record, DOI metadata, and available correction, expression-of-concern, or retraction information when the source materially affects the conclusion.

## Output

Use [output-templates.md](references/output-templates.md). Cite significant claims near their supporting sources and include stable links or identifiers. Distinguish source statements from synthesis or inference. Record the date through which time-sensitive research was checked, coverage limits, and unresolved questions.

Do not transmit confidential, unpublished, identifiable, proprietary, or culturally restricted material to another external service or connector without explicit permission and an authorized use.

Never invent a source, quotation, identifier, search result, database access status, or verification step.
