# Routing

Choose by the user's immediate need:

| Need | Primary skill | Expected artifact |
| --- | --- | --- |
| Turn a topic or stalled idea into a feasible project | Research Project Planner | Project blueprint or research-assistant brief |
| Find and verify scholarly or primary sources | Academic Source Searcher | Search plan, research log, and source brief |
| Review and synthesize a body of scholarship | Literature Review Helper | Search record, source matrix, and synthesis |
| Develop or pressure-test a claim | Argument Builder | Argument map and evidence-needs table |
| Reorganize a substantial draft | Draft Revision Coach | Reverse outline and prioritized revision plan |
| Verify citations, source support, quotations, and APA 7 form | APA 7 Citation Checker | Traceability and citation audit |
| Improve sentences and paragraphs | Scholarly Writing Editor | Edited passage and style-pattern report |
| Compare venues and plan submission | Publication Planner | Venue comparison and submission plan |
| Adapt completed research for a broader audience | Public Writing Adapter | Evidence-faithful public version |

Useful dependencies:

- Source searching normally precedes a defensible literature synthesis.
- Argument building may reveal a targeted source-search need.
- Structural revision normally precedes line editing.
- Citation checking should follow substantive revision and precede submission.
- Publication requirements can affect final structure, length, disclosures, and citation style.

Do not impose these dependencies when the user has already completed the earlier work.
