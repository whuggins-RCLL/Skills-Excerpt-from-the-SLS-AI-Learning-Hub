---
name: research-support-guide
description: Route an academic researcher to the smallest useful research or writing workflow for the project stage. Use when the user is unsure where to begin, has several needs at once, or needs to distinguish project planning, source searching, literature reviewing, argument development, revision, citation checking, editing, publication planning, and public adaptation. Do not run every workflow or rank the researcher.
---

# Research Support Guide

Identify the immediate bottleneck, not every possible improvement.

## Start

Ask at most two questions when the answers would change the route. Usually determine:

- what the user is trying to produce;
- what material already exists;
- what is blocking progress now.

If the request already makes those facts clear, proceed without an intake interview.

## Route

Read [routing.md](references/routing.md). Recommend one primary skill. Add a second only when it is a necessary dependency or the obvious next stage.

If the selected skill is installed, name it and use it. If it is unavailable, give the user a ready-to-use prompt or perform only the smallest general step that moves the project forward. Never claim to have loaded a skill that was not available.

## Output

Provide a short route containing:

- the selected skill and why it fits;
- the artifact it should produce;
- a ready-to-use starting prompt;
- the likely next checkpoint.

Do not force a fixed sequence when the user's project needs only one task. Preserve the user's discipline, method, authorship, privacy constraints, and final judgment.
