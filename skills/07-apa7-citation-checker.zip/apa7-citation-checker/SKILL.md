---
name: apa7-citation-checker
description: Audit academic citations for source existence, claim support, quotation accuracy, current scholarly-record status, and APA Style 7th edition form. Use when the user provides a draft, references, quotations, or sources and needs a traceability check, DOI or metadata verification, correction or retraction review, in-text/reference-list matching, or APA 7 corrections. Do not claim verification without opening the source or treat citation formatting as proof of substantive support.
---

# APA 7 Citation Checker

Verify the source, the proposition, and the citation separately.

## Set the standard

Confirm that APA 7 is the governing style or the desired default. If a course, discipline, publisher, or venue requires another style, do not force APA 7; ask whether to limit the task to substantive traceability or follow the required style instead.

Read the supplied draft, reference list, notes, and sources before auditing. For a large draft, agree on scope or work in clearly labeled batches.

## Audit

Follow [workflow.md](references/workflow.md). Use [apa7-quick-guide.md](references/apa7-quick-guide.md) for common APA 7 checks, then verify unusual source types against current official APA Style guidance.

Use original publisher, repository, DOI, catalog, database, archival, or official records. A DOI lookup or metadata record can verify identity but cannot prove that the full source supports the claim. Open and examine the relevant source text, table, figure, data, or material before marking proposition support as verified.

Check corrections, retractions, expressions of concern, and version history when material. State which records were checked and their limits. Do not imply a comprehensive status check if the available tools or access do not support one.

Classify each item as: verified; verified with qualification; indirect support; source mismatch; quotation or locator problem; scholarly-record issue; APA 7 issue; inaccessible; missing; or not checked.

## Output

Use [output-templates.md](references/output-templates.md). Separate substantive support from APA formatting. Provide proposed corrections, never invented publication details. Preserve the author's wording unless a correction is requested, and pause before bulk or meaning-changing edits.

Do not transmit confidential, unpublished, identifiable, proprietary, or culturally restricted material to another external service or connector without explicit permission and an authorized use.

Never fabricate an author, title, date, DOI, URL, page, quotation, source status, or access result. Generated citations and citation-manager output always require human review.
