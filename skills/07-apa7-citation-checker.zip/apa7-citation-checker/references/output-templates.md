# Output Templates

## Citation and Traceability Audit

| Draft location | Proposition or quotation | In-text citation | Reference entry | Identity verified | Support result | Quote and locator | Record status | APA 7 | Stable link | Action |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

Use result labels: verified; verified with qualification; indirect support; source mismatch; quotation or locator problem; scholarly-record issue; APA 7 issue; inaccessible; missing; not checked.

## Summary

- High-priority substantive problems
- Missing or inaccessible sources
- Corrections, retractions, or version concerns
- APA 7 patterns to fix
- Items requiring author judgment
- Scope and limits of the audit
