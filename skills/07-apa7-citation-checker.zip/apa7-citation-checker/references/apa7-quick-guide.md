# APA 7 Verification Quick Guide

Use this guide for common checks. For unusual sources or ambiguity, consult current official APA Style guidance rather than extrapolating.

## Identity and pairing

- APA uses an author-date in-text system. Each ordinary in-text citation should map to one reference entry, and each ordinary reference entry should be cited in the text.
- Direct quotations normally include a page number or another suitable locator. A locator for a paraphrase is optional but can help readers find complex or lengthy material.
- Use a secondary citation only when the original cannot reasonably be consulted. Identify the original in text, cite the source actually read using “as cited in,” and include only the source actually read in the reference list.

## Common reference patterns

- **Journal article:** Author. (Year). Article title. *Journal Title, volume*(issue), page range or article number. DOI
- **Book:** Author. (Year). *Book title* (edition when applicable). Publisher. DOI
- **Chapter:** Author. (Year). Chapter title. In Editor (Ed.), *Book title* (page range). Publisher. DOI
- **Report:** Group or author. (Year). *Report title* (report number when applicable). Publisher when different from author. URL
- **Webpage:** Author or group. (Date). *Page title*. Site name when different from author. URL
- **Dataset or software:** Creator. (Year). *Title* (version) [Data set or Computer software]. Publisher or repository. DOI or URL

Apply sentence case, italics, punctuation, author ordering, dates, editions, and source elements according to the actual source type. Do not infer missing details from a similar record.

## DOIs and URLs

- Present a DOI as a URL beginning `https://doi.org/`.
- Prefer the DOI when one exists. Do not add a database URL for an ordinary academic-database item that readers can locate through its reference, unless APA guidance for that source type calls for it.
- Use retrieval dates only for content designed to change over time and not archived.

## Author lists

- In a reference entry, list up to 20 authors. For 21 or more, list the first 19, insert an ellipsis, and add the final author.
- Apply the correct in-text rule for one author, two authors, three or more authors, groups, ambiguous author-date combinations, and no-author works.

## Authoritative guidance

Checked August 27, 2026:

- APA Style and Grammar Guidelines: https://apastyle.apa.org/style-grammar-guidelines
- APA reference-list guide: https://apastyle.apa.org/instructional-aids/creating-reference-list.pdf
- APA DOI and URL guidance: https://apastyle.apa.org/style-grammar-guidelines/references/dois-urls
- Crossref metadata retrieval: https://www.crossref.org/documentation/retrieve-metadata/
- Crossmark status and update information: https://www.crossref.org/documentation/crossmark/

The target venue's current author instructions control when they modify APA Style.
