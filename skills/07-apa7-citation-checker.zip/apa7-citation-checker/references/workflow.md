# Workflow

1. Confirm the governing citation style, audit scope, and whether the user supplied full sources.
2. Inventory in-text citations, reference entries, quotations, figures or tables attributed to others, and other source-dependent claims.
3. Match every in-text citation to its reference entry and every reference entry to actual use, allowing legitimate APA exceptions.
4. Verify bibliographic identity from the original or authoritative record: creators, date, title, source, volume and issue, pages or article number, edition or version, publisher or repository, DOI, and URL as applicable.
5. Open the source and compare the draft's proposition with the relevant passage, data, table, figure, or material.
6. Verify quotation wording, omissions, alterations, and locator. Distinguish a page printed on the item from a PDF viewer page.
7. Determine whether support is direct, qualified, indirect, contradictory, or absent. Check whether the draft overstates causality, scope, population, certainty, or consensus.
8. Check the current scholarly record when material: publisher or repository version, correction, retraction, expression of concern, and other update metadata.
9. Audit APA 7 mechanics only after identity and support checks. Never invent missing metadata to make a citation look complete.
10. Record verified, qualified, not verified, inaccessible, and not checked items separately.
11. Perform a final traceability review: each major source-dependent proposition has an appropriate source, the link or identifier resolves when available, and the source says what the draft attributes to it.
12. Propose corrections and high-priority author decisions.
