# Structure Patterns

Use these as diagnostic possibilities, not templates to impose.

- **Empirical article:** problem and prior work; question or hypotheses; method; results; interpretation; limitations; implications. Reporting details depend on the method and venue.
- **Qualitative or mixed-methods study:** positionality and context may be structurally central; integrate method, analytic process, evidence, reflexivity, and limits in the form the discipline recognizes.
- **Humanities argument:** problem or interpretive intervention; context and conversation; close analysis or primary materials; counterreading or complication; implications. Chronological, thematic, or object-centered structures may be more appropriate than IMRaD.
- **Theoretical or conceptual paper:** conceptual problem; definitions; existing approaches; proposed framework; comparison or test cases; implications and limits.
- **Historical study:** question and historiography; source base and provenance; contextual chronology or themes; analysis; alternative interpretations; contribution and limits.
- **Design, policy, or evaluation paper:** problem and stakeholders; criteria; evidence and alternatives; design or intervention; implementation context; tradeoffs; evaluation; limitations.
- **Review article:** review purpose and method; organizing framework; synthesis of agreement, disagreement, methods, and gaps; implications and limits.

Consult the target venue and discipline's current guidance before treating any pattern as required.
