# Workflow

1. Identify audience, purpose, genre, discipline, central contribution, and draft stage.
2. State the draft's apparent central claim or question and compare it with the author's stated purpose.
3. Create a reverse outline at the section or paragraph level appropriate to the draft.
4. Test whether every unit has a clear job and advances the inquiry, method, evidence, interpretation, or implications.
5. Locate buried claims, unsupported transitions, repeated background, premature conclusions, and evidence appearing too early or too late.
6. Test the order and proportionality of context, prior work, theory, method, evidence, analysis, counterargument, limitations, and implications as the genre requires.
7. Track important terms, actors, timeframes, populations, and levels of certainty for consistency.
8. Identify substantive gaps separately from structural moves, citation checks, and sentence-level edits.
9. Propose a prioritized revision sequence with rationale, dependencies, effort, and a checkpoint before meaning-changing changes.
10. Preserve voice and disciplinary form; flag rather than invent missing support.
