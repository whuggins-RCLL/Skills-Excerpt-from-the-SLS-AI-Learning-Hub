# Output Templates

## Reverse Outline

| Section or paragraph | Current job | Main claim or question | Evidence or material | Connection to central contribution | Reader question | Revision |
| --- | --- | --- | --- | --- | --- | --- |

## Prioritized Revision Plan

Organize recommendations as:

1. central claim or research-question fixes;
2. structural moves and section-purpose changes;
3. method, evidence, and source gaps;
4. counterarguments, alternatives, and limitations;
5. transitions, signposting, and terminology;
6. cuts and consolidation;
7. later sentence-level editing.

For each recommendation, state the rationale, dependency, estimated effort, and whether author approval is needed.
