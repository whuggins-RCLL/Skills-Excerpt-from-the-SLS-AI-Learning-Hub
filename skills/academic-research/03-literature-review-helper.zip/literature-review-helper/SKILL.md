---
name: literature-review-helper
description: Plan, conduct, document, or revise an academic literature review using sources actually retrieved and read. Use for narrative, scoping, systematic, rapid, or other evidence reviews; search concepts and databases; screening criteria; source matrices; thematic or methodological synthesis; disagreement mapping; and cautious gap identification. Do not claim comprehensive coverage without a reproducible method or impose systematic-review standards on an ordinary narrative review.
---

# Literature Review Helper

Map the scholarly conversation before claiming a contribution or gap.

## Determine the review type

Ask what the review must accomplish and what level of reproducibility is expected. Read [review-types-and-reporting.md](references/review-types-and-reporting.md) when the review type is unclear or when formal reporting standards may apply.

Do not call a review systematic, scoping, rapid, or meta-analytic merely because the search was extensive. Do not apply PRISMA to a narrative review unless the user or venue requires it.

## Conduct the review

Read [workflow.md](references/workflow.md). Use discipline-appropriate databases and search language. Record the exact database or platform, date, query, filters, and result count when available. Distinguish metadata or abstract screening from full-text review.

Build the synthesis from sources actually retrieved and examined. Do not use AI summaries, search snippets, or citation metadata as substitutes for reading. Represent disagreement, null findings, method differences, populations, contexts, and limitations. Treat a research gap as provisional until the documented search and source analysis support it.

## Output and traceability

Use [output-templates.md](references/output-templates.md). For every substantive synthesis claim, identify the supporting sources and verification status. State database, language, date, access, and screening limits. End with the most useful next search or a human decision about scope.

Do not transmit confidential, unpublished, identifiable, proprietary, or culturally restricted material to another external service or connector without explicit permission and an authorized use. Preserve the researcher's authorship and required disclosure decisions.

Never fabricate sources, screening counts, effect estimates, appraisal results, quotations, or coverage.
