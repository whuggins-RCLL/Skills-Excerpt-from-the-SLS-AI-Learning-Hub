# Workflow

1. Define the review purpose, audience, type, disciplines, dates, languages, source types, and update date.
2. Frame the question using a field-appropriate structure when helpful; do not force a clinical framework onto other disciplines.
3. Create concepts, synonyms, variant spellings, controlled vocabulary, names, and citation-chaining paths.
4. Select multiple source environments when their coverage, indexing, disciplinary scope, publication type, or regional representation differs.
5. Record each search exactly enough to reproduce or explain it.
6. Establish inclusion and exclusion criteria before drawing conclusions; record reasons at the level the review type requires.
7. Deduplicate and screen transparently. Keep title/abstract and full-text decisions distinct.
8. Retrieve and read included sources. Extract only information the source supports.
9. Appraise source and method quality using a suitable disciplinary tool when the review requires it. Name the tool and do not invent a score.
10. Synthesize by concepts, findings, methods, populations, settings, time, and disagreement rather than producing an annotated list or simple vote count.
11. Verify quotations, bibliographic identities, persistent links, and any correction or retraction status checked.
12. State coverage limits, unresolved disagreement, provisional gaps, and the update plan.
