# Review Types and Reporting

Choose the design from the review's purpose; names imply methods and should not be used casually.

- **Narrative review:** interprets and synthesizes a body of work without claiming exhaustive retrieval. Explain how sources were selected and acknowledge selection limits.
- **Scoping review:** maps the breadth, characteristics, and gaps of evidence using an explicit protocol and screening process. Consult the appropriate PRISMA extension.
- **Systematic review:** answers a focused question with a prespecified, reproducible search, eligibility, appraisal, and synthesis process. Use PRISMA 2020 for reporting when applicable.
- **Rapid review:** streamlines specified systematic-review methods because of time or resource limits. Disclose every shortcut and likely consequence.
- **Meta-analysis:** statistically combines compatible quantitative results. It requires defensible effect extraction and model choices; do not calculate one without suitable methodological expertise and data.
- **Qualitative evidence synthesis, integrative review, umbrella review, and other designs:** follow the standards appropriate to that design and discipline.

Reporting guidance is not a substitute for a valid review method.

Authoritative starting points, checked August 27, 2026:

- PRISMA 2020 and extensions: https://www.prisma-statement.org/
- EQUATOR reporting-guideline library: https://www.equator-network.org/reporting-guidelines/
- APA Journal Article Reporting Standards: https://apastyle.apa.org/jars

Use the current official checklist or extension, record the version and date checked, and defer to the researcher's discipline, protocol, and target venue.
