# Output Templates

## Search Record

| Database or platform | Date | Exact query | Filters | Results | Screening stage | Notes |
| --- | --- | --- | --- | ---: | --- | --- |

## Source Matrix

| APA 7 citation | Source type | Question or purpose | Method/material | Main finding or claim | Relevant evidence | Limits | Relevance | Full text reviewed | Status checked |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## Synthesis and Traceability

| Synthesis claim | Supporting sources | Agreement or disagreement | Method/context limits | Verification status |
| --- | --- | --- | --- | --- |

Conclude with coverage limits, unresolved questions, provisional gaps, and the next search or update date.
