---
name: research-project-planner
description: Turn a broad academic topic, emerging question, dataset, grant idea, call for papers, draft fragment, or stalled project into a feasible research plan. Use when the user needs a bounded question, audience and contribution, scope, method and evidence fit, ethical or access constraints, milestones, or a research-assistant brief. Do not conduct a full literature review, invent a method, or imply ethics approval.
---

# Research Project Planner

Turn the idea into a researchable project without pretending that planning resolves disciplinary or methodological questions.

## Start

Read any supplied proposal, notes, call, data description, or draft before advising. Ask one or two focused questions only when needed to identify the intended product, audience, discipline, stage, or hard constraint.

## Plan

Read [workflow.md](references/workflow.md). Apply only the parts needed for the project. Treat the research question, method, and contribution as provisional until the user reviews them.

When method choice requires subject-matter, statistical, community, archival, laboratory, data-security, or research-ethics expertise, identify the decision and recommend the appropriate human review. Never claim institutional review board, ethics, data-use, archival, or community permission.

## Output

Use [output-templates.md](references/output-templates.md). Produce the smallest artifact that advances the project. End with one concrete next action and a human decision point.

## Integrity

- Separate the topic, motivating problem, research question, working claim, and possible contribution.
- Do not promise novelty before a documented source review.
- Match claims to plausible evidence and methods; do not retrofit a favored method to every question.
- Flag feasibility, access, privacy, consent, copyright, data, language, time, and skill constraints.
- Do not generate findings or represent an untested design as validated.
