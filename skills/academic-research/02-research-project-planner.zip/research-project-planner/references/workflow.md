# Workflow

1. Identify the project stage, intended product, audience, discipline, and practical constraints.
2. Separate the broad topic, motivating problem, primary question, subquestions, working claim, and possible contribution.
3. Define central terms and create a scope fence: included, excluded, and deferred.
4. Test whether the question is answerable and whether the proposed evidence can support the intended claim.
5. Compare plausible approaches without prescribing a method outside available expertise. Consider empirical, computational, interpretive, historical, theoretical, design, participatory, and mixed-method possibilities when relevant.
6. Identify likely source environments, data or materials, access paths, and missing expertise.
7. Identify ethics, consent, privacy, confidentiality, intellectual-property, community, safety, and data-governance checkpoints.
8. Build milestones around decisions and evidence, not merely dates.
9. Record assumptions, risks, and stopping or pivot criteria.
10. End with one immediate research action and one decision for the researcher.
