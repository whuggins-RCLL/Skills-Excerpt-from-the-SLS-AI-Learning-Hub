# Output Templates

## Research Project Blueprint

- Working title
- Intended product and audience
- Motivating problem
- Primary question and necessary subquestions
- Key terms and assumptions
- Possible contribution and what must be verified
- Scope fence: include, exclude, defer
- Method and evidence fit
- Source, data, material, or participant needs
- Access, ethics, permissions, privacy, and expertise
- Milestones and decision gates
- Risks, pivot points, and stopping criteria
- Immediate next action
- Human-review checkpoint

## Research-Assistant Brief

State the task, purpose, scope, source environments, date and language limits, inclusion and exclusion rules, required search log, deliverable, verification standard, escalation questions, and researcher review point.
