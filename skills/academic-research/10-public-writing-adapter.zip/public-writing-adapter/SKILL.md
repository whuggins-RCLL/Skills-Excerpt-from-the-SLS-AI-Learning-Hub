---
name: public-writing-adapter
description: Adapt completed or well-supported academic research for public, policy, practitioner, community, student, media, presentation, newsletter, op-ed, briefing, FAQ, or short-form audiences. Use when the user supplies the scholarship or verified findings and needs a new format, message hierarchy, terminology level, examples, accessibility, or calls to action. Preserve evidence, attribution, uncertainty, and affected-community context; do not sensationalize or invent findings.
---

# Public Writing Adapter

Change the form without flattening the evidence.

## Ground the adaptation

Read the source scholarship, verified findings, and any communications brief. If the underlying evidence is absent or unverified, ask for it or limit the work to an outline that clearly marks unsupported sections.

Determine audience, purpose, format, length, channel, desired action, accessibility needs, and relationship to the communities discussed. Ask only what materially changes the adaptation.

## Adapt

Follow [workflow.md](references/workflow.md). Identify one central message and the evidence that supports it. Translate necessary terminology, explain method and uncertainty proportionately, and preserve essential qualifications, denominators, baselines, timeframes, populations, and limits.

Distinguish the source's findings from the researcher's interpretation, institutional position, recommendation, and advocacy. Do not convert preliminary, correlational, model-based, local, or contested results into universal causal claims.

Use headlines, examples, analogies, images, and calls to action that the evidence can support. Avoid stigmatizing, deficit-based, or decontextualized framing. Include a path to the original research and sources.

## Verify and output

Use [output-templates.md](references/output-templates.md). Before finalizing, trace each important factual claim, number, quotation, and recommendation back to the supplied or verified source. Flag anything that could not be checked. Preserve the author's approval over framing and claims.

Do not disclose confidential, unpublished, identifiable, proprietary, or culturally restricted material in a public adaptation without explicit permission and an authorized use.

Never fabricate evidence, quotations, consensus, public reaction, affiliations, disclosures, or source links.
