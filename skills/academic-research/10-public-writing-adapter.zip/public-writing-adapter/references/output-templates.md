# Output Templates

Supported formats include a public explainer, policy brief, practitioner summary, community handout, student explainer, op-ed outline, media Q&A, presentation narrative, newsletter item, FAQ, and executive brief.

## Adaptation Brief

- Audience and purpose
- Central message
- Evidence base
- Essential qualification
- Terms requiring explanation
- Likely misunderstanding
- Accessibility and community considerations
- Desired action
- Link to full research and sources
- Claims not made

## Traceability Check

| Public claim, number, or quotation | Supporting source | Direct or adapted | Qualification retained | Verification status |
| --- | --- | --- | --- | --- |
