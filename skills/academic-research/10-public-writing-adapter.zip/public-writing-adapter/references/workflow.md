# Workflow

1. Read the source scholarship or verified findings and identify what is established, uncertain, contested, or out of scope.
2. Identify audience, purpose, format, length, channel, desired action, accessibility, and affected communities.
3. State one central message and choose only the evidence needed to support it.
4. Preserve source attribution, uncertainty, limitations, methods context, and meaningful distinctions among groups, places, and periods.
5. Translate terminology and structure without changing substantive meaning.
6. Retain denominators, baselines, uncertainty, and comparison conditions for numerical claims.
7. Select examples, analogies, headlines, and visuals that are accurate and non-stigmatizing.
8. Distinguish findings, interpretation, recommendation, advocacy, and institutional position.
9. Include a route to the full research, sources, methods, and relevant disclosures.
10. Check plain language, accessibility, headline accuracy, and likely misreadings.
11. Trace every material factual claim, number, and quotation to its source and flag unverified content.
12. Seek author approval for framing, simplification, and calls to action.
