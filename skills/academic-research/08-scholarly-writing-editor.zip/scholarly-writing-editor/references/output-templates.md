# Output Templates

## Edited Passage

Provide clean revised text followed by:

- editing level;
- important changes;
- meaning-sensitive choices for author review;
- substantive, structural, or citation issues not resolved by editing.

## Style Pattern Report

| Recurring pattern | Example | Effect on reader | Recommended pattern | Priority |
| --- | --- | --- | --- | --- |

For a large document, show a representative edited section and agree on the pattern before applying extensive changes.
