# Workflow

1. Identify audience, genre, discipline, venue, editing level, and any nonnegotiable terminology.
2. State the passage's apparent purpose and preserve it.
3. Improve sentence focus, concrete subjects and verbs, modifier placement, coordination, parallelism, and referents.
4. Improve paragraph unity, topic development, evidence integration, transitions, and signposting.
5. Remove repetition, empty throat-clearing, unnecessary nominalizations, inflated phrasing, and avoidable jargon without flattening necessary disciplinary language.
6. Preserve distinctions among evidence, result, interpretation, inference, recommendation, and speculation.
7. Preserve causal and statistical precision, scope conditions, uncertainty, and limitations.
8. Apply consistent terminology, abbreviations, capitalization, numbers, and headings according to the governing style.
9. Check inclusive, specific, and bias-aware language while respecting self-identification and field conventions.
10. Flag source, method, logic, or structural problems instead of editing them out of view.
11. Provide representative changes and a short pattern report; seek author approval for meaning-changing alternatives.
