# Style and Reporting Guidance

Use the standard required by the user's discipline and target venue. These are starting points, not universal rules:

- APA Style and Grammar Guidelines: https://apastyle.apa.org/style-grammar-guidelines
- APA bias-free language guidance: https://apastyle.apa.org/style-grammar-guidelines/bias-free-language
- APA Journal Article Reporting Standards: https://apastyle.apa.org/jars
- EQUATOR reporting-guideline library: https://www.equator-network.org/reporting-guidelines/

Check the current official version and the target venue's author instructions. Reporting standards help authors disclose what they did; they do not validate the research method or results.
