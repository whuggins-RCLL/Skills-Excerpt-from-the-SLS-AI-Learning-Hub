# Examples

Use realistic faculty-facing examples. Do not name real Stanford people, students, clients, or confidential projects.

- "Help me use Legal Research Planner with this topic or draft."
- "Show me the smallest useful next step, then pause."
- "Use SLS databases where appropriate and label what still needs verification."
