SLS Writing Partner Set
=======================

Ten skills that review your writing without writing it for you: a policy
gate, the full review workflow, and eight focused checks you can run on
their own.

WHAT IS IN THIS FILE
--------------------
01. SLS AI Use Gate  (sls-ai-use-gate.zip)
02. SLS Writing Review  (sls-writing-review.zip)
03. SLS Argument and Structure Check  (sls-argument-structure.zip)
04. SLS Flow and Organization Check  (sls-flow-organization.zip)
05. SLS Clarity and Precision Check  (sls-clarity-precision.zip)
06. SLS Audience and Reception Check  (sls-audience-reception.zip)
07. SLS Counterargument Stress Test  (sls-counterargument.zip)
08. SLS Claims and Source Traceability  (sls-claims-traceability.zip)
09. SLS Bluebook Audit  (sls-bluebook-audit.zip)
10. SLS Genre Fit Check  (sls-genre-fit.zip)

HOW TO INSTALL
--------------
This file is a set: it holds 10 skill ZIPs. Unzip this set once, then
upload each skill ZIP *without* unzipping it. Both platforms want the packaged
skill file.

  ChatGPT  Plugins > switch to Skills > + > drop the skill ZIP in.
  Claude   Customize > Add (top right) > drop the skill ZIP in.

You add a skill once and it stays available across chats. Start a fresh chat
after installing, and name the skill in your first message.

The "Install a skill" page on the AI Learning Hub has the full walkthrough,
including a short screen recording for each platform.

BEFORE YOU USE THESE
--------------------
Confirm your course's AI policy with the instructor; the Honor Code applies
either way. For access, tools, or research help, email the Robert Crown Law
Library at library@law.stanford.edu.
