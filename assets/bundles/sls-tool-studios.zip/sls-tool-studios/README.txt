SLS Tool Studios Set
====================

Six guided introductions to the AI tools available through the Robert Crown
Law Library and Stanford, plus the explorer for anything not on the list.

WHAT IS IN THIS FILE
--------------------
01. SLS Harvey Learning Studio  (sls-harvey-learning-studio.zip)
02. SLS Legora Learning Studio  (sls-legora-learning-studio.zip)
03. SLS LexText Learning Studio  (sls-lextext-learning-studio.zip)
04. SLS CICERO Oral Argument Studio  (sls-cicero-oral-argument-studio.zip)
05. SLS Gemini Notebook Learning Studio  (sls-gemini-notebook-learning-studio.zip)
06. SLS AI Tool Explorer  (sls-ai-tool-explorer.zip)

HOW TO INSTALL
--------------
This file is a set: it holds 6 skill ZIPs. Unzip this set once, then
upload each skill ZIP *without* unzipping it. Both platforms want the packaged
skill file.

  ChatGPT  Plugins > switch to Skills > + > drop the skill ZIP in.
  Claude   Customize > Add (top right) > drop the skill ZIP in.

You add a skill once and it stays available across chats. Start a fresh chat
after installing, and name the skill in your first message.

The "Install a skill" page that came with these skills has the full
walkthrough, including a short screen recording for each platform.

LICENCE
-------
These skills are licensed under the Apache License, Version 2.0. The full text
is in LICENSE beside this file, and again inside each skill ZIP, along with the
copyright notice in NOTICE. You may use, modify, and redistribute them on those
terms.

BEFORE YOU USE THESE
--------------------
Confirm your course's AI policy with the instructor; the Honor Code applies
either way. For access, tools, or research help, email the Robert Crown Law
Library at library@law.stanford.edu.
