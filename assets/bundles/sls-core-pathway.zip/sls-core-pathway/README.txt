SLS Core Pathway Set
====================

The five foundational skills in order, from your first AI orientation to
auditing AI output like a lawyer.

WHAT IS IN THIS FILE
--------------------
01. SLS AI Orientation  (sls-ai-orientation.zip)
02. SLS AI Task-Fit Coach  (sls-ai-task-fit-coach.zip)
03. SLS Case Learning Coach  (sls-case-learning-coach.zip)
04. SLS Legal Research Learning Coach  (sls-legal-research-learning-coach.zip)
05. SLS AI Verification Lab  (sls-ai-verification-lab.zip)

HOW TO INSTALL
--------------
This file is a set: it holds 5 skill ZIPs. Unzip this set once, then
upload each skill ZIP *without* unzipping it. Both platforms want the packaged
skill file.

  ChatGPT  Plugins > switch to Skills > + > drop the skill ZIP in.
  Claude   Customize > Add (top right) > drop the skill ZIP in.

You add a skill once and it stays available across chats. Start a fresh chat
after installing, and name the skill in your first message.

The "Install a skill" page that came with these skills has the full
walkthrough, including a short screen recording for each platform.

LICENCE
-------
These skills are licensed under the Apache License, Version 2.0. The full text
is in LICENSE beside this file, and again inside each skill ZIP, along with the
copyright notice in NOTICE. You may use, modify, and redistribute them on those
terms.

BEFORE YOU USE THESE
--------------------
Confirm your course's AI policy with the instructor; the Honor Code applies
either way. For access, tools, or research help, email the Robert Crown Law
Library at library@law.stanford.edu.
