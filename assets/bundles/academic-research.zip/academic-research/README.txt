Academic Research & Writing Skills Set
======================================

Ten discipline-neutral skills for a general academic research agent: route a
request, scope a project, run a literature review, search and verify
sources, build and pressure-test an argument, diagnose a draft's structure,
check APA 7 citations, edit the prose, plan publication, and adapt the work
for a wider audience. Install all ten for a general research agent, or only
the ones the work needs.

WHAT IS IN THIS FILE
--------------------
01. Research Support Guide  (research-support-guide.zip)
02. Research Project Planner  (research-project-planner.zip)
03. Literature Review Helper  (literature-review-helper.zip)
04. Academic Source Searcher  (academic-source-searcher.zip)
05. Argument Builder  (argument-builder.zip)
06. Draft Revision Coach  (draft-revision-coach.zip)
07. APA 7 Citation Checker  (apa7-citation-checker.zip)
08. Scholarly Writing Editor  (scholarly-writing-editor.zip)
09. Publication Planner  (publication-planner.zip)
10. Public Writing Adapter  (public-writing-adapter.zip)

HOW TO INSTALL
--------------
This file is a set: it holds 10 skill ZIPs. Unzip this set once, then
upload each skill ZIP *without* unzipping it. Both platforms want the packaged
skill file.

  ChatGPT  Plugins > switch to Skills > + > drop the skill ZIP in.
  Claude   Customize > Add (top right) > drop the skill ZIP in.

You add a skill once and it stays available across chats. Start a fresh chat
after installing, and name the skill in your first message.

The "Install a skill" page that came with these skills has the full
walkthrough, including a short screen recording for each platform.

LICENCE
-------
These skills are licensed under the MIT License, copyright (c) 2026 SLS
Faculty AI Skills contributors, and adapted in 2026 for discipline-neutral
academic research.
The full text is in LICENSE beside this file, and again inside each
skill ZIP, along with the copyright notice in NOTICE. Keep both with the files
if you pass them on.

BEFORE YOU USE THESE
--------------------
Confirm your course's AI policy with the instructor; the Honor Code applies
either way. For access, tools, or research help, email the Robert Crown Law
Library at library@law.stanford.edu.
